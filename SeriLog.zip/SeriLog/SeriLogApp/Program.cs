using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();


WebApplication app;
try
{
    
    var config = new ConfigurationBuilder()
        .AddJsonFile("appsettings.json").Build();  
    //Initialize Logger    
    Log.Logger = new LoggerConfiguration()
        .ReadFrom.Configuration(config)
        .CreateLogger(); 
    
    
   // Log.Logger = new LoggerConfiguration().CreateLogger();
    /*builder.Host.UseSerilog((
            (ctx, lc) => lc
                .ReadFrom.Configuration(ctx.Configuration))
    );*/

    builder.Host.UseSerilog();
    app = builder.Build();
    app.UseSerilogRequestLogging();
    Log.Information("--> App is starting up ....");
}
catch (Exception e)
{
    Log.Fatal(e, "The app failed to start bruh!!");
    throw;
}
finally
{
    Log.CloseAndFlush();
}



// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapRazorPages();

app.Run();