﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SeriLogApp.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {
        _logger.LogInformation("My exercise app web app logging is here <----");

        try
        {
            for (int i = 0; i < 100; i++)
            {
                if (i == 56)
                {
                    throw new Exception("it our on purpose exception");
                }
                else
                {
                    _logger.LogInformation("the value {LoopCountValue}", i);
                }
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "--> I caught you man yoooo!! <<***--");
        }
    }
}